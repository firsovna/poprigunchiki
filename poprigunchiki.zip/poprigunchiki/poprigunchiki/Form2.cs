﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace poprigunchiki
{
    public partial class Form2 : Form
    {
        Model1 db = new Model1();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //Agent agent = (Agent)agentBindingSource.Current;  //код на показ картинки 
            //try
            //{
            //    if (agent == null) return;
            //    if (agent.Logo != "")
            //    {
            //        string str = agent.Logo.Substring(1);
            //        pictureBox2.Image = Image.FromFile(str);
            //    }
            //    else
            //    {
            //        pictureBox2.Image = Image.FromFile("agent.png");
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
            agentBindingSource.DataSource = db.Agent.ToList();
            agentTypeBindingSource.DataSource = db.AgentType.ToList();
            // TODO: данная строка кода позволяет загрузить данные в таблицу "poprigunDataSet.AgentType". При необходимости она может быть перемещена или удалена.
            this.agentTypeTableAdapter.Fill(this.poprigunDataSet.AgentType);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "poprigunDataSet.ProductSale". При необходимости она может быть перемещена или удалена.
            this.productSaleTableAdapter.Fill(this.poprigunDataSet.ProductSale);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "poprigunDataSet.Agent". При необходимости она может быть перемещена или удалена.
            this.agentTableAdapter.Fill(this.poprigunDataSet.Agent);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Agent agent = (Agent)agentBindingSource.Current;
            Form3 frm = new Form3();
            frm.db = db;
            frm.agent = null;
            DialogResult dr = frm.ShowDialog(); ;
            if (dr == DialogResult.OK)
            {
                agentBindingSource.DataSource = null;
                agentBindingSource.DataSource = db.Agent.ToList();
            }
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);//всплывающее окно 
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 db = new Form1();//переход на 1ю форму
            db.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 db = new Form4();//переход на 4ю форму
            db.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            agentTableAdapter.Update(poprigunDataSet);//сохранение в бд poprigunchiki, в таблицу agent
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
