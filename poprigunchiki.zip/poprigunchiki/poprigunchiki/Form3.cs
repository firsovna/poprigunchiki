﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace poprigunchiki
{
    public partial class Form3 : Form
    {
        public Model1 db { get; set; }
        public Agent agent { get; set; }
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "poprigunDataSet1.Agent". При необходимости она может быть перемещена или удалена.
            this.agentTableAdapter.Fill(this.poprigunDataSet1.Agent);
            //if (agent == null)
            //{
              //  agentBindingSource.AddNew();

             //   Text = " Добавление нового клиента ";
         //   }
           // else
          //  {
          //      agentBindingSource.Add(agent);
                //iDTextBox.ReadOnly = true;
           //     Text = " Корректировка клиента " + agent.ID;
          //  }

       }

        private void button4_Click(object sender, EventArgs e)
        {
            // if (agent == null)
            //{
            //    agent = (Agent)agentBindingSource.List[0];
            //   db.Agent.Add(agent);
            //  }
            //  try
            //  {
            //      db.SaveChanges();
            //       DialogResult = DialogResult.OK;
            //  }
            //  catch (Exception ex)
            // {
            //  MessageBox.Show(" Ошибка " + ex.InnerException.InnerException.Message);
            // }
            Form2 db = new Form2();//переход на 2ю форму
            db.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;//закрытие формы
        }

        private void agentBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.agentBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.poprigunDataSet1);

        }
    }
}
